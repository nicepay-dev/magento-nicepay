<?php

namespace Nicepay\CreditCardNice\Controller\CreditCardNice;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Framework\Translate\Inline\StateInterface;
use Magento\Sales\Model\Order;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;
use Psr\Log\LoggerInterface;
use Magento\Framework\App\ObjectManager;

class Notification extends Action
{
    private $logger;
    private $transportBuilder;
    private $inlineTranslation;
    private $scopeConfig;
    private $order;

    public function __construct(
        Context $context,
        LoggerInterface $logger,
        TransportBuilder $transportBuilder,
        StateInterface $inlineTranslation,
        ScopeConfigInterface $scopeConfig,
        Order $order
    ) {
        parent::__construct($context);
        $this->logger = $logger;
        $this->transportBuilder = $transportBuilder;
        $this->inlineTranslation = $inlineTranslation;
        $this->scopeConfig = $scopeConfig;
        $this->order = $order;
    }

    public function execute()
    {
        try {
            $this->includes();
            $nicepay = new \NicepayLib();

            $pushParameters = ['tXid', 'referenceNo', 'amt', 'merchantToken'];
            $nicepay->extractNotification($pushParameters);

            $tXid = $nicepay->getNotification('tXid');
            $referenceNo = $nicepay->getNotification('referenceNo');
            $amt = $nicepay->getNotification('amt');
            $pushedToken = $nicepay->getNotification('merchantToken');

            $iMid = $this->getConfigData('merchant_id');
            $mKey = $this->getConfigData('merchant_key');

            $nicepay->set('tXid', $tXid);
			$this->logger->info("tXid : ".$tXid);
            $nicepay->set('referenceNo', $referenceNo);
			$this->logger->info("referenceNo : ".$referenceNo);
            $nicepay->set('amt', $amt);
			$this->logger->info("amt : ".$amt);
            $nicepay->set('iMid', $iMid);
			$this ->logger->info("iMid : ".$iMid);
            $nicepay->set('mKey', $mKey);
			$this->logger->info("mKey : ".$mKey);


            $merchantToken = $nicepay->merchantTokenC();
			
			$this->logger->info("incoming merchant Token : ".$pushedToken);
			$this->logger->info("calculated merchant Token : ".$merchantToken);

            if ($pushedToken === $merchantToken) {
                $order = $this->order->loadByIncrementId($referenceNo);

                $paymentStatus = $nicepay->checkPaymentStatus($iMid, $tXid, $referenceNo, $amt);

                if (isset($paymentStatus->status) && $paymentStatus->status === '0') {
                    $this->updateOrderStatus($order, $this->getConfigData('payment_status'));
                } else {
                    $this->updateOrderStatus($order, 'canceled');
                }
            } else {
                $this->logger->warning('Merchant token mismatch.');
            }
        } catch (\Exception $e) {
            $this->logger->error('Error processing notification: ' . $e->getMessage());
        }
    }

    private function includes()
    {
        $libPath = BP . '/app/code/Nicepay/CreditCardNice/Library/NicepayLib.php';
        if (file_exists($libPath)) {
            require_once $libPath;
        } else {
            throw new \Exception('Nicepay library not found.');
        }
    }

    private function getConfigData($field, $storeId = null)
    {
        $path = 'payment/credit_card_nice/' . $field;
        return $this->scopeConfig->getValue($path, ScopeInterface::SCOPE_STORE, $storeId);
    }

    private function updateOrderStatus($order, $status)
    {
        $order->setStatus($status)->setState($status)->save();
        $order->addStatusToHistory($status, 'Order status updated to ' . $status . ' by NICEPay notification.');
        $this->sendOrderEmail($order);
    }

    private function sendOrderEmail($order)
    {
        try {
            $templateId = 'nicepay_order_status_email';
            $billing = $order->getBillingAddress();

            $templateVars = [
                'store' => $order->getStore(),
                'customer_name' => $billing->getFirstname() . ' ' . $billing->getLastname(),
                'order' => $order
            ];

            $from = [
                'email' => $this->scopeConfig->getValue('trans_email/ident_support/email', ScopeInterface::SCOPE_STORE),
                'name' => $this->scopeConfig->getValue('trans_email/ident_support/name', ScopeInterface::SCOPE_STORE),
            ];

            $this->inlineTranslation->suspend();
            $transport = $this->transportBuilder
                ->setTemplateIdentifier($templateId)
                ->setTemplateOptions([
                    'area' => \Magento\Framework\App\Area::AREA_FRONTEND,
                    'store' => $order->getStoreId()
                ])
                ->setTemplateVars($templateVars)
                ->setFrom($from)
                ->addTo($billing->getEmail(), $billing->getFirstname() . ' ' . $billing->getLastname())
                ->getTransport();

            $transport->sendMessage();
            $this->inlineTranslation->resume();
        } catch (\Exception $e) {
            $this->logger->error('Error sending order email: ' . $e->getMessage());
        }
    }
}
