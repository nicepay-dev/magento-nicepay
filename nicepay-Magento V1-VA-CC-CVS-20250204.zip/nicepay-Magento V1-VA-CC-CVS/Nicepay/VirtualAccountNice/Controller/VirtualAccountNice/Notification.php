<?php

namespace Nicepay\VirtualAccountNice\Controller\VirtualAccountNice;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Framework\Translate\Inline\StateInterface;
use Magento\Sales\Model\Order;
use Psr\Log\LoggerInterface;
use Magento\Store\Model\ScopeInterface;

class Notification extends Action
{
    private $scopeConfig;
    private $transportBuilder;
    private $inlineTranslation;
    private $order;
    private $logger;

    public function __construct(
        Context $context,
        ScopeConfigInterface $scopeConfig,
        TransportBuilder $transportBuilder,
        StateInterface $inlineTranslation,
        Order $order,
        LoggerInterface $logger
    ) {
        parent::__construct($context);
        $this->scopeConfig = $scopeConfig;
        $this->transportBuilder = $transportBuilder;
        $this->inlineTranslation = $inlineTranslation;
        $this->order = $order;
        $this->logger = $logger;
    }

    public function execute()
    {
        try {
            // Load Nicepay library
            $this->logger->debug("nicepay notification start ");
            $this->logger->debug('Raw Input: ' . json_encode($_REQUEST));

            $this->includeLibrary();
            $nicepay = new \NicepayLib($this->logger);

            // Extract notification parameters
            $pushParameters = ['tXid', 'referenceNo', 'amt', 'merchantToken'];
            $nicepay->extractNotification($pushParameters);

            $tXid = $nicepay->getNotification('tXid');
            $this->logger->debug('tXid: ' . $tXid);

            $referenceNo = $nicepay->getNotification('referenceNo');
            $this->logger->debug('referenceNo: ' . $referenceNo);

            $amt = $nicepay->getNotification('amt');
            $this->logger->debug('amt: ' . $amt);

            $pushedToken = $nicepay->getNotification('merchantToken');
            $this->logger->debug('pushedToken: ' . $pushedToken);


            $iMid = $this->getConfigData('merchant_id');
            $mKey = $this->getConfigData('merchant_key');

            // Generate merchant token
            $nicepay->set('tXid', $tXid);
            $nicepay->set('referenceNo', $referenceNo);
            $nicepay->set('amt', $amt);
            $nicepay->set('iMid', $iMid);
            $nicepay->set('mKey', $mKey);
            $merchantToken = $nicepay->merchantTokenC();

            if ($pushedToken === $merchantToken) {
                
                $order = $this->order->loadByIncrementId($referenceNo);

                $this->logger->debug("Check status for payment : ". $tXid);
                $paymentStatus = $nicepay->checkPaymentStatus($iMid, $tXid, $referenceNo, $amt);
                $this->logger->debug("Payment status : ". $paymentStatus->status);

                if (isset($paymentStatus->status) && $paymentStatus->status === '0') {
                    $this->updateOrderStatus($order, $this->getConfigData('payment_status'));
                } else {
                    $this->updateOrderStatus($order, 'canceled');
                }
            } else {
                $this->logger->warning('Merchant token mismatch.');
            }
        } catch (\Exception $e) {
            $this->logger->error('Error processing notification: ' . $e->getMessage());
        }
    }

    private function includeLibrary()
    {
        $libPath = BP . '/app/code/Nicepay/VirtualAccountNice/Library/NicepayLib.php';
        if (file_exists($libPath)) {
            require_once $libPath;
        } else {
            throw new \Exception('Nicepay library not found.');
        }
    }

    private function getConfigData($field, $storeId = null)
    {
        $path = 'payment/virtual_account_nice/' . $field;
        return $this->scopeConfig->getValue($path, ScopeInterface::SCOPE_STORE, $storeId);
    }

    private function updateOrderStatus($order, $status)
    {
        $order->setStatus($status)->setState($status)->save();
        $order->addStatusToHistory($status, 'Order status updated to ' . $status . ' by NICEPay notification.');
        $this->sendOrderEmail($order);
    }

    private function sendOrderEmail($order)
    {
        try {
            $templateId = 'nicepay_order_status_email';
            $billing = $order->getBillingAddress();

            $templateVars = [
                'store' => $order->getStore(),
                'customer_name' => $billing->getFirstname() . ' ' . $billing->getLastname(),
                'order' => $order
            ];

            $from = [
                'email' => $this->scopeConfig->getValue('trans_email/ident_support/email', ScopeInterface::SCOPE_STORE),
                'name' => $this->scopeConfig->getValue('trans_email/ident_support/name', ScopeInterface::SCOPE_STORE),
            ];

            $this->inlineTranslation->suspend();
            $transport = $this->transportBuilder
                ->setTemplateIdentifier($templateId)
                ->setTemplateOptions([
                    'area' => \Magento\Framework\App\Area::AREA_FRONTEND,
                    'store' => $order->getStoreId()
                ])
                ->setTemplateVars($templateVars)
                ->setFrom($from)
                ->addTo($billing->getEmail(), $billing->getFirstname() . ' ' . $billing->getLastname())
                ->getTransport();

            $transport->sendMessage();
            $this->inlineTranslation->resume();
        } catch (\Exception $e) {
            $this->logger->error('Error sending order email: ' . $e->getMessage());
        }
    }
}
